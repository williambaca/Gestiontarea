﻿using System;
using System.Collections.Generic;

#nullable disable

namespace tareas.Models
{
    public partial class TblEmpresa
    {
        public TblEmpresa()
        {
            TblUsuarios = new HashSet<TblUsuario>();
        }

        public int EmpNit { get; set; }
        public string EmpNombre { get; set; }
        public string EmpLocalidad { get; set; }
        public string EmpDireccion { get; set; }
        public string EmpEmail { get; set; }
        public string EmpDireccionWeb { get; set; }
        public int EmpTelefono { get; set; }
        public int PkEmpIdEmpresa { get; set; }

        public virtual ICollection<TblUsuario> TblUsuarios { get; set; }
    }
}
