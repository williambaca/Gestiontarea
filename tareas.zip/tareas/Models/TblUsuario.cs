﻿using System;
using System.Collections.Generic;

#nullable disable

namespace tareas.Models
{
    public partial class TblUsuario
    {
        public string UsuTipoDocumento { get; set; }
        public long UsuDocumento { get; set; }
        public string UsuNombres { get; set; }
        public string UsuApellidos { get; set; }
        public string UsuEmail { get; set; }
        public int UsuTelefono { get; set; }
        public string UsuDireccion { get; set; }
        public string UsuLocalidad { get; set; }
        public string UsuClave { get; set; }
        public int FkEmpIdEmpresa { get; set; }
        public int PkUsuIdUsuario { get; set; }

        public virtual TblEmpresa FkEmpIdEmpresaNavigation { get; set; }
    }
}
