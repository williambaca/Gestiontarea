﻿using System;
using System.Collections.Generic;

#nullable disable

namespace tareas.Models
{
    public partial class TblRol
    {
        public string RolNombre { get; set; }
        public string RolDescripcion { get; set; }
        public int PkRolIdRol { get; set; }
    }
}
