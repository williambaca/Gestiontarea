﻿using System;
using System.Collections.Generic;

#nullable disable

namespace tareas.Models
{
    public partial class TblUsuarioHasRol
    {
        public int FkUsuIdUsuario { get; set; }
        public int FkRolIdRol { get; set; }

        public virtual TblRol FkRolIdRolNavigation { get; set; }
        public virtual TblUsuario FkUsuIdUsuarioNavigation { get; set; }
    }
}
