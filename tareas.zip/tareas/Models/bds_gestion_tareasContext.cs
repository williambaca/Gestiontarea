﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace tareas.Models
{
    public partial class bds_gestion_tareasContext : DbContext
    {
        public bds_gestion_tareasContext()
        {
        }

        public bds_gestion_tareasContext(DbContextOptions<bds_gestion_tareasContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblEmpresa> TblEmpresas { get; set; }
        public virtual DbSet<TblRol> TblRols { get; set; }
        public virtual DbSet<TblTarea> TblTareas { get; set; }
        public virtual DbSet<TblUsuario> TblUsuarios { get; set; }
        public virtual DbSet<TblUsuarioHasRol> TblUsuarioHasRols { get; set; }
        public virtual DbSet<TblUsuarioHasTarea> TblUsuarioHasTareas { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseMySql("server=localhost;database=bds_gestion_tareas;user=root;pwd=12345", Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.31-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasCharSet("utf8");

            modelBuilder.Entity<TblEmpresa>(entity =>
            {
                entity.HasKey(e => e.PkEmpIdEmpresa)
                    .HasName("PRIMARY");

                entity.ToTable("tbl_empresa");

                entity.Property(e => e.PkEmpIdEmpresa)
                    .HasColumnType("int(10)")
                    .HasColumnName("PK_EMP_IdEmpresa");

                entity.Property(e => e.EmpDireccion)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("EMP_Direccion");

                entity.Property(e => e.EmpDireccionWeb)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("EMP_DireccionWeb");

                entity.Property(e => e.EmpEmail)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("EMP_Email");

                entity.Property(e => e.EmpLocalidad)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("EMP_Localidad");

                entity.Property(e => e.EmpNit)
                    .HasColumnType("int(10)")
                    .HasColumnName("EMP_Nit");

                entity.Property(e => e.EmpNombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("EMP_Nombre");

                entity.Property(e => e.EmpTelefono)
                    .HasColumnType("int(20)")
                    .HasColumnName("EMP_Telefono");
            });

            modelBuilder.Entity<TblRol>(entity =>
            {
                entity.HasKey(e => e.PkRolIdRol)
                    .HasName("PRIMARY");

                entity.ToTable("tbl_rol");

                entity.Property(e => e.PkRolIdRol)
                    .HasColumnType("int(10)")
                    .ValueGeneratedNever()
                    .HasColumnName("PK_ROL_IdRol");

                entity.Property(e => e.RolDescripcion)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("ROL_Descripcion");

                entity.Property(e => e.RolNombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("ROL_Nombre");
            });

            modelBuilder.Entity<TblTarea>(entity =>
            {
                entity.HasKey(e => e.PkTraIdTarea)
                    .HasName("PRIMARY");

                entity.ToTable("tbl_tarea");

                entity.Property(e => e.PkTraIdTarea)
                    .HasColumnType("int(10)")
                    .ValueGeneratedNever()
                    .HasColumnName("PK_TRA_IdTarea");

                entity.Property(e => e.TraDescripcion)
                    .IsRequired()
                    .HasColumnType("text")
                    .HasColumnName("TRA_Descripcion");

                entity.Property(e => e.TraEstado)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("TRA_Estado");

                entity.Property(e => e.TraFechaFinal)
                    .HasColumnType("date")
                    .HasColumnName("TRA_Fecha_Final");

                entity.Property(e => e.TraFechaInicio)
                    .HasColumnType("date")
                    .HasColumnName("TRA_Fecha_Inicio");

                entity.Property(e => e.TraNombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("TRA_Nombre");
            });

            modelBuilder.Entity<TblUsuario>(entity =>
            {
                entity.HasKey(e => e.PkUsuIdUsuario)
                    .HasName("PRIMARY");

                entity.ToTable("tbl_usuario");

                entity.HasIndex(e => e.FkEmpIdEmpresa, "FK_EMP_IdEmpresa");

                entity.Property(e => e.PkUsuIdUsuario)
                    .HasColumnType("int(10)")
                    .HasColumnName("PK_USU_IdUsuario");

                entity.Property(e => e.FkEmpIdEmpresa)
                    .HasColumnType("int(10)")
                    .HasColumnName("FK_EMP_IdEmpresa");

                entity.Property(e => e.UsuApellidos)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Apellidos");

                entity.Property(e => e.UsuClave)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("USU_Clave");

                entity.Property(e => e.UsuDireccion)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Direccion");

                entity.Property(e => e.UsuDocumento)
                    .HasColumnType("bigint(20)")
                    .HasColumnName("USU_Documento");

                entity.Property(e => e.UsuEmail)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Email");

                entity.Property(e => e.UsuLocalidad)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Localidad");

                entity.Property(e => e.UsuNombres)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Nombres");

                entity.Property(e => e.UsuTelefono)
                    .HasColumnType("int(20)")
                    .HasColumnName("USU_Telefono");

                entity.Property(e => e.UsuTipoDocumento)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("USU_Tipo_Documento");

                entity.HasOne(d => d.FkEmpIdEmpresaNavigation)
                    .WithMany(p => p.TblUsuarios)
                    .HasForeignKey(d => d.FkEmpIdEmpresa)
                    .HasConstraintName("tbl_usuario_ibfk_1");
            });

            modelBuilder.Entity<TblUsuarioHasRol>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbl_usuario_has_rol");

                entity.HasIndex(e => e.FkRolIdRol, "FK_ROL_IdRol");

                entity.HasIndex(e => e.FkUsuIdUsuario, "FK_USU_IdUsuario");

                entity.Property(e => e.FkRolIdRol)
                    .HasColumnType("int(10)")
                    .HasColumnName("FK_ROL_IdRol");

                entity.Property(e => e.FkUsuIdUsuario)
                    .HasColumnType("int(10)")
                    .HasColumnName("FK_USU_IdUsuario");

                entity.HasOne(d => d.FkRolIdRolNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.FkRolIdRol)
                    .HasConstraintName("tbl_usuario_has_rol_ibfk_1");

                entity.HasOne(d => d.FkUsuIdUsuarioNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.FkUsuIdUsuario)
                    .HasConstraintName("tbl_usuario_has_rol_ibfk_2");
            });

            modelBuilder.Entity<TblUsuarioHasTarea>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbl_usuario_has_tarea");

                entity.HasIndex(e => e.FkTraIdTarea, "FK_TRA_IdTarea");

                entity.HasIndex(e => new { e.FkUsuIdUsuario, e.FkTraIdTarea }, "FK_USU_IdUsuario");

                entity.Property(e => e.FkTraIdTarea)
                    .HasColumnType("int(10)")
                    .HasColumnName("FK_TRA_IdTarea");

                entity.Property(e => e.FkUsuIdUsuario)
                    .HasColumnType("int(10)")
                    .HasColumnName("FK_USU_IdUsuario");

                entity.HasOne(d => d.FkTraIdTareaNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.FkTraIdTarea)
                    .HasConstraintName("tbl_usuario_has_tarea_ibfk_2");

                entity.HasOne(d => d.FkUsuIdUsuarioNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.FkUsuIdUsuario)
                    .HasConstraintName("tbl_usuario_has_tarea_ibfk_1");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
